using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class GetLivePoint : MonoBehaviour
{
    private UInt32 livePoint = 1;
    [SerializeField] private Text livePoints;
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.CompareTag("cherry"))
        {
            ++livePoint;
            livePoints.text = "LivePoint: " + livePoints;
            Destroy(col.gameObject);
        }
    }
}
