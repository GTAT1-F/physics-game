using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GetHighScore : MonoBehaviour
{
    private UInt32 highScore;
    [SerializeField] private Text highScore;
    
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.CompareTag("item"))
        {
            highScore += 10;
            highScore.text = "Highscore: " + highScore;
            Destroy(col.gameObject);
        }
    }
}
